<!DOCTYPE html>
<html lang="en">

<head>

<?php include"head.php" ?>

    <title>ลงทะเบียน</title>


    <link href="../css/bootstrap-datepicker.css" rel="stylesheet">
    <link href="../dist/css/administyle.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]--><style>
.vl {
    border-left: 6px solid #5cb85c;
    height: 500px;
}
</style>


</head>

<body>

        <?php
    session_start();
    if($_SESSION['userid'] == "")
    {
        echo "Please Login!";
        exit();
    }

    if($_SESSION['adminlevel'] != "1")
    {
        echo "<h1>คุณไม่มีสิทธิ์ใช้งานในหน้านี้</h1>";
        header( "location: register.php" );
        exit(5);
    } 

    
    mysql_connect($HOST_NAME,$USERNAME,$PASSWORD);
    mysql_select_db($DB_NAME);
    $strSQL = "SELECT * FROM administrator WHERE userid = '".$_SESSION['userid']."' ";
    $objQuery = mysql_query($strSQL);
    $objResult = mysql_fetch_array($objQuery);
?>

    <div id="wrapper">

        <!-- Navigation -->
       <?php include'nav.php'?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">ทำรายการถอนเงิน</h1>
                </div>

                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            ถอนเงิน
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-4">


<?php
date_default_timezone_set("Asia/Bangkok");
$connection = mysql_connect($HOST_NAME,$USERNAME,$PASSWORD); // Establishing Connection with Server
$db = mysql_select_db($DB_NAME, $connection);
 // Selecting Database from Server
if(isset($_POST['submit'])){ // Fetching variables of the form which travels in URL
$category = $_POST['category'];
$agent = $_POST['agent'];
$surelastname = $_POST['surelastname'];
$bank = $_POST['bank'];
$banknumber = $_POST['banknumber'];
$user = $_POST['user'];
$withdraw = $_POST['withdraw'];
$deposit = $_POST['deposit'];
$bonus = $_POST['bonus'];
$tperson = $_POST['tperson'];
$date_now = date('Y-m-d H:i:s', strtotime($_POST['date_now']));

if($surelastname !=''||$deposit !=''){
//Insert Query of SQL
$query = mysql_query("insert into scclub_data(category, agent, date_now, surelastname, bank, banknumber, user, withdraw, deposit, bonus, tperson) values ('$category', '$agent', '$date_now', '$surelastname', '$bank', '$banknumber', '$user', '$withdraw', '$deposit', '$bonus', '$tperson')");
echo "<br/><br/><span>Data Inserted successfully...!!</span>";
}
else{
echo "<p>Insertion Failed <br/> Some Fields are Blank....!!</p>";
}
}
mysql_close($connection); // Closing Connection with Server

?>

<form name="formcheck" action="#" method="get">
<input class="checkuser col-lg-8" type="text" name="sendget" id="sendget" value=""> .
<button type="submi2" name="submit2" class="btn btn-success"> ตรวจสอบ</button>
</form>


 <?php
$objConnect = mysql_connect($HOST_NAME,$USERNAME,$PASSWORD) or die("Error Connect to Database");
$objDB = mysql_select_db($DB_NAME);
$strSQL = "SELECT * FROM scclub_data WHERE category='สมัครสมาชิก' AND user = '".$_GET["sendget"]."' ";
if(empty($_GET)) {
            $strSQL = "SELECT * FROM scclub_data WHERE user='uffq00000' ";
        }
$objQuery = mysql_query($strSQL);
$objResult = mysql_fetch_array($objQuery);
if(!$objResult)
{
    echo "ไม่พบ Username = ".$_GET["sendget"];
}

?>
<hr>


                                        <form name="formsend" action="rewithdraw.php" method="post">
                                            <input type="hidden" class="form-control" name="category" value="ถอนเงิน">
                                         <input class="form-control" placeholder="Username" type="text" name="user"value="<?php echo $objResult["user"];?>"><br>
                                           
                                            <input type="hidden" class="form-control" name="tperson" value="<?php echo $objResult2["username"];?>">
                                    <div class="radio">บัญชีเดิมพัน :
                                                <label>
                                                    <input type="radio" name="agent"  name="agent" value="UFABET" checked="">UFABET 
                                                </label>
                                                <label> 
                                                    <input type="radio" name="agent"  name="agent" value="GCLUB" >GCLUB  
                                                </label>
                                                <label>
                                                    <input type="radio" name="agent"  name="agent" value="SBOBET" >SBOBET 
                                                </label>
                                            </div>
                                            <input type="" class="form-control" name="date_now" value="<?php echo date('Y-m-d H:i:s') ?>">
                                            <br>
                                        <input type="text" class="form-control" placeholder="ชื่อ นามสกุล" name="surelastname" value="<?php echo $objResult["surelastname"];?>"><br>
                                        <select class="form-control" name="bank">
                                                <option value="<?php echo $objResult["bank"];?>"><?php echo $objResult["bank"];?></option>
                                                <option value="BBL">ธนาคารกรุงเทพ</option>
                                                <option value="KBANK">ธนาคารกสิกรไทย</option>
                                                <option value="SCB">ธนาคารไทยพาณิชย์</option>
                                                <option value="KTB">ธนาคารกรุงไทย</option>
                                                <option value="TMB">ธนาคารทหารไทย</option>
                                                <option value="BAY">ธนาคารกรุงศรีอยุธยา</option>
                                                <option value="GSB">ธนาคารออมสิน</option>
                                            </select><br>
                                        <input class="form-control" placeholder="เลขบัญชีธนาคาร" type="text" name="banknumber" id="banknumber" value="<?php echo $objResult["banknumber"];?>"><br>
                                        <input class="form-control" placeholder="จำนวนถอนเงิน" type="text" name="withdraw" value=""><br>
                                        <button type="submit" name="submit" value="Insert" class="btn btn-success">ส่งข้อมูล</button>
                                    </form>

                                </div>

                                <div class="col-lg-8 vl">
                        <div class="panel panel-red">
                        <div class="panel-heading">
                            การทำรายการล่าสุด
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th>รหัสธุรกรรม</th>
                                        <th>เวลา</th>
                                        <th>ชื่อบัญชี</th>
                                        <th>เลขที่บัญชี</th>
                                        <th>ธนาคาร</th>
                                        <th>จำนวนถอน</th>
                                        <th>ผู้ตรวจสอบ</th>
                                        <th>สถานะ</th>
                                        <th>หมายเหตุ</th>
                                    </tr>
                                </thead>
                                <tbody>



<?php
        $db = new PDO('mysql:host='.$HOST_NAME.';dbname='.$DB_NAME.';'.$CHAR_SET,$USERNAME,$PASSWORD);

        
    
        $sql = "SELECT category,transactionid,user,date_now,surelastname,banknumber,bank,tel,idline,deposit,bonus,withdraw,tperson,aperson,note,liststatus,ip
                FROM scclub_data WHERE (aperson != '' AND withdraw !='')
                ORDER BY transactionid DESC LIMIT 10"; 

        $query = $db->query($sql);
    
        while($row = $query->fetch()) {        

            echo '
                                    <tr>
                                        <td>'.$row['transactionid'].'</td>
                                        <td>'.date('H:i:s',strtotime($row['date_now'])).'</td>
                                        <td>'.$row['surelastname'].'</td>
                                        <td>'.$row['banknumber'].'</td>
                                        <td>'.$row['bank'].'</td>
                                        <td>'.$row['withdraw'].'</td>
                                        <td>'.$row['aperson'].'</td>
                                        <td>'.$row['liststatus'].'</td>
                                        <td>'.$row['note'].'</td>
                                    </tr>'
                                     ;

  }
        
?>                                    
                           
                         
                                </tbody>
                            </table>
                            <!-- /.table-responsive -->

                        </div>
                        <!-- /.panel-body -->
                    </div>

                                </div>

                            </div>

                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>


 

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <script src="../js/bootstrap-datepicker.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true,
            "aaSorting" : [[0, "desc"]],
            "fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
                    if ( aData[9] == "unconfirm" )
                    {
                        $('td', nRow).css('background-color', 'Red');
                    }
                    else if ( aData[9] == "confirm" )
                    {
                        $('td', nRow).css('background-color', 'Green');
                    }
                }

        });
    });

    $('.input-daterange input').each(function() {
    $(this).datepicker('clearDates');
});
    </script>

</body>

</html>
