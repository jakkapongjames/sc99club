<!DOCTYPE html>


<head>

<?php include"head.php" ?>

    <title>SB Admin 2 - Bootstrap Admin Theme</title>



    <link href="../css/bootstrap-datepicker.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->


</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
       <?php include'nav.php'?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <div class="container contact-form">
                        
            <form action="save-creuser.php?transactionid=<?php echo $_GET["transactionid"];?>" name="frmEdit" method="post">
 <?php
$objConnect = mysql_connect($HOST_NAME,$USERNAME,$PASSWORD) or die("Error Connect to Database");
$objDB = mysql_select_db($DB_NAME);
$strSQL = "SELECT * FROM scclub_data WHERE transactionid = '".$_GET["transactionid"]."' ";
$objQuery = mysql_query($strSQL);
$objResult = mysql_fetch_array($objQuery);
if(!$objResult)
{
    echo "Not found transactionid=".$_GET["transactionid"];
}
else
{
?>
                <h2 style="text-align: center;">สร้างบัญชีเดิมพัน ของธุรกรรมที่ (<?php echo $objResult["transactionid"];?>)</h2>
               <div class="row">
                    <div class="col-md-6">
                            <input type="hidden" name="txttransactionid" class="form-control" value="<?php echo $objResult["transactionid"];?>"/>
                        <div class="form-group col-md-12"> ชื่อ - นามสกุล
                            <input type="text" name="" class="form-control" value="<?php echo $objResult["surelastname"];?>" disabled/>
                        </div>

                        <div class="form-group col-md-6"> เบอร์โทรศัพท์
                            <input type="text" name="" class="form-control" value="<?php echo $objResult["tel"];?>" disabled/>
                        </div>

                        <div class="form-group col-md-6"> ID LINE
                            <input type="text" name="" class="form-control" value="<?php echo $objResult["idline"];?>" disabled/>
                        </div>



                        
                        <div class="form-group col-md-6">
                            จำนวนเงินฝาก
                            <input type="text" name="" class="form-control" value="<?php echo $objResult["deposit"];?>" disabled/>
                        </div>

                        
                        <div class="form-group col-md-6">
                            โบนัส
                            <input type="text" name="txtbonus" class="form-control" value="<?php echo $objResult["bonus"];?>" />
                        </div>
                
                        <div class="form-group col-md-6"> เลขที่บัญชี
                            <input type="text" name="" class="form-control" value="<?php echo $objResult["banknumber"];?>" disabled/>
                        </div>

                        <div class="form-group col-md-6"> ธนาคาร
                            <input type="text" name="" class="form-control" value="<?php echo $objResult["bank"];?>" disabled/>
                        </div>

                        <div class="form-group col-md-12"> Username
                            <input type="text" name="txtuser" class="form-control" value=""/>
                        </div>

                        <div class="form-group col-md-6">
                            <input type="hidden" name="txtaperson" class="form-control" value="<?php echo $objResult2["username"];?>" />
                        </div>

                                                                         <div class="form-group col-md-12">
                            <h4>สถานะการตรวจสอบธุรกรรม</h4>
                                                <select class="form-control" name="txtliststatus">
                        <option name="txtliststatus" value="confirm">ผ่าน</option>
                        <option name="txtliststatus" value="unconfirm">ไม่ผ่าน</option>
                    </select>
                        </div>


                       
                            <div class="form-group col-md-12">
                            <h5 style="text-align: center;">ผู้สร้างบัญชี (<?php echo $objResult2["adminname"];?>)</h5>
                        </div>





                        

                        

                          

                        
                    </div>
                    <div class="col-md-6" style="margin-bottom: 50px;">
                        <h1 style="text-align: right;">สร้างบัญชีเดิมพัน</h1>
                         <!-- <h1 style="text-align: center; color: red;">ทำรายการฝากเงินเวลา <?php echo date('H:i:s',strtotime($objResult['date_now'])) ;?> </h1> close -->
                            <img src="../img/creuser2.png" class="img-responsive">
                            <div class="row">
                                <br>
                                <div class="col-md-4"><a href="http://ag.ufabet.com/Public/Default11.aspx" target="_blank"><img src="../img/ufabet.png" class="img-responsive"></div></a>
                                <div class="col-md-4"><a href="http://ag.ufabet.com/Public/Default11.aspx" target="_blank"><img src="../img/sbobet.png" class="img-responsive"></div>
                                <div class="col-md-4"><img src="../img/gclub.png" class="img-responsive"></div>
                            </div>
                    </div>
                </div>
                <div class="row">

                    <input class="btn btn-success btn-lg btn-block" type="submit" name="submit" value="submit">
                </div>
            </form>

            <?php
  }
  mysql_close($objConnect);
  ?>

                </div>

                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <script src="../js/bootstrap-datepicker.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->


</body>

</html>
